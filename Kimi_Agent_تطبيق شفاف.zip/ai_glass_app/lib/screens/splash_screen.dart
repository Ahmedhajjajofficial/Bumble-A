import 'dart:math' show pi, sin, cos;
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/glass_widgets.dart';
import '../theme/app_colors.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _logoController;
  late final AnimationController _particlesController;
  late final Animation<double> _logoScale;
  late final Animation<double> _logoOpacity;

  @override
  void initState() {
    super.initState();

    _logoController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );

    _particlesController = AnimationController(
      duration: const Duration(milliseconds: 3000),
      vsync: this,
    )..repeat();

    _logoScale = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutBack),
      ),
    );

    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoController,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );

    _logoController.forward();

    // Navigate to home screen after animation
    Future.delayed(const Duration(milliseconds: 3000), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) =>
                const HomeScreen(),
            transitionsBuilder:
                (context, animation, secondaryAnimation, child) {
              return FadeTransition(
                opacity: animation,
                child: child,
              );
            },
            transitionDuration: const Duration(milliseconds: 800),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _logoController.dispose();
    _particlesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDark
                ? [
                    const Color(0xFF0F0F0F),
                    const Color(0xFF1A1A2E),
                    const Color(0xFF16213E),
                  ]
                : [
                    const Color(0xFFF8F9FA),
                    const Color(0xFFE9ECEF),
                    const Color(0xFFDEE2E6),
                  ],
          ),
        ),
        child: Stack(
          children: [
            // Animated particles background
            AnimatedBuilder(
              animation: _particlesController,
              builder: (context, child) {
                return CustomPaint(
                  size: Size.infinite,
                  painter: ParticlesPainter(
                    progress: _particlesController.value,
                    isDark: isDark,
                  ),
                );
              },
            ),

            // Glass orbs
            ...List.generate(3, (index) {
              return Positioned(
                left: [50.0, 250.0, 150.0][index],
                top: [100.0, 300.0, 500.0][index],
                child: GlassContainer(
                  width: [120.0, 80.0, 150.0][index],
                  height: [120.0, 80.0, 150.0][index],
                  borderRadius: 60,
                  blur: 40,
                  opacity: 0.08,
                )
                    .animate()
                    .fadeIn(duration: 1000.ms, delay: (index * 200).ms)
                    .scale(begin: const Offset(0.5, 0.5), end: const Offset(1, 1)),
              );
            }),

            // Main content
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo
                  AnimatedBuilder(
                    animation: _logoController,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _logoOpacity.value,
                        child: Transform.scale(
                          scale: _logoScale.value,
                          child: GlassContainer(
                            width: 140,
                            height: 140,
                            borderRadius: 35,
                            blur: 30,
                            opacity: 0.2,
                            border: Border.all(
                              color: AppColors.primary.withOpacity(0.3),
                              width: 2,
                            ),
                            child: const Icon(
                              Icons.auto_awesome,
                              size: 60,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 40),

                  // App name
                  Text(
                    'AI Glass',
                    style: TextStyle(
                      color: isDark ? Colors.white : Colors.black,
                      fontSize: 42,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'SF Pro Display',
                      letterSpacing: -1,
                    ),
                  )
                      .animate()
                      .fadeIn(duration: 800.ms, delay: 600.ms)
                      .slideY(begin: 0.3, end: 0),

                  const SizedBox(height: 12),

                  // Tagline
                  Text(
                    'Experience the Future of AI',
                    style: TextStyle(
                      color: isDark ? Colors.white60 : Colors.black54,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'SF Pro Text',
                    ),
                  )
                      .animate()
                      .fadeIn(duration: 800.ms, delay: 800.ms)
                      .slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 60),

                  // Loading indicator
                  LoadingIndicator()
                      .animate()
                      .fadeIn(duration: 600.ms, delay: 1000.ms),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LoadingIndicator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        GlassContainer(
          width: 8,
          height: 8,
          borderRadius: 4,
          blur: 10,
          opacity: 0.3,
        )
            .animate(onPlay: (controller) => controller.repeat())
            .scale(
              duration: 600.ms,
              begin: const Offset(1, 1),
              end: const Offset(1.5, 1.5),
            )
            .then()
            .scale(
              duration: 600.ms,
              begin: const Offset(1.5, 1.5),
              end: const Offset(1, 1),
            ),
        const SizedBox(width: 8),
        GlassContainer(
          width: 8,
          height: 8,
          borderRadius: 4,
          blur: 10,
          opacity: 0.3,
        )
            .animate(onPlay: (controller) => controller.repeat())
            .scale(
              duration: 600.ms,
              delay: 200.ms,
              begin: const Offset(1, 1),
              end: const Offset(1.5, 1.5),
            )
            .then()
            .scale(
              duration: 600.ms,
              begin: const Offset(1.5, 1.5),
              end: const Offset(1, 1),
            ),
        const SizedBox(width: 8),
        GlassContainer(
          width: 8,
          height: 8,
          borderRadius: 4,
          blur: 10,
          opacity: 0.3,
        )
            .animate(onPlay: (controller) => controller.repeat())
            .scale(
              duration: 600.ms,
              delay: 400.ms,
              begin: const Offset(1, 1),
              end: const Offset(1.5, 1.5),
            )
            .then()
            .scale(
              duration: 600.ms,
              begin: const Offset(1.5, 1.5),
              end: const Offset(1, 1),
            ),
      ],
    );
  }
}

class ParticlesPainter extends CustomPainter {
  final double progress;
  final bool isDark;

  ParticlesPainter({required this.progress, required this.isDark});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withOpacity(0.1)
      ..style = PaintingStyle.fill;

    final random = List.generate(20, (index) {
      return Offset(
        (index * 37) % size.width,
        (index * 53) % size.height,
      );
    });

    for (int i = 0; i < random.length; i++) {
      final offset = random[i];
      final animatedOffset = Offset(
        offset.dx + sin(progress * 2 * pi + i) * 20,
        offset.dy + cos(progress * 2 * pi + i * 0.5) * 15,
      );

      canvas.drawCircle(
        animatedOffset,
        2 + (i % 3),
        paint,
      );
    }

    // Draw connecting lines
    final linePaint = Paint()
      ..color = (isDark ? Colors.white : Colors.black).withOpacity(0.03)
      ..strokeWidth = 0.5;

    for (int i = 0; i < random.length; i++) {
      for (int j = i + 1; j < random.length; j++) {
        final p1 = Offset(
          random[i].dx + sin(progress * 2 * pi + i) * 20,
          random[i].dy + cos(progress * 2 * pi + i * 0.5) * 15,
        );
        final p2 = Offset(
          random[j].dx + sin(progress * 2 * pi + j) * 20,
          random[j].dy + cos(progress * 2 * pi + j * 0.5) * 15,
        );

        final distance = (p1 - p2).distance;
        if (distance < 100) {
          canvas.drawLine(p1, p2, linePaint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
