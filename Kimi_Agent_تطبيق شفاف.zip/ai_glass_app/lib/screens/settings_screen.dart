import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../providers/api_provider.dart';
import '../widgets/glass_widgets.dart';
import '../theme/app_colors.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final themeProvider = context.watch<ThemeProvider>();
    final apiProvider = context.watch<APIProvider>();

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          // Header
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Settings',
                    style: TextStyle(
                      color: isDark ? Colors.white : Colors.black,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'SF Pro Display',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Customize your AI experience',
                    style: TextStyle(
                      color: isDark ? Colors.white60 : Colors.black54,
                      fontSize: 15,
                      fontFamily: 'SF Pro Text',
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Settings Sections
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Appearance Section
                _buildSectionTitle('Appearance', isDark),
                const SizedBox(height: 12),
                GlassCard(
                  borderRadius: 20,
                  blur: 20,
                  opacity: 0.12,
                  child: Column(
                    children: [
                      _buildThemeSelector(context, themeProvider),
                      Divider(
                        color: isDark ? Colors.white10 : Colors.black5,
                        height: 1,
                      ),
                      _buildGlassEffectToggle(context, themeProvider),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // API Configuration Section
                _buildSectionTitle('AI Models & API', isDark),
                const SizedBox(height: 12),
                GlassCard(
                  borderRadius: 20,
                  blur: 20,
                  opacity: 0.12,
                  child: Column(
                    children: [
                      _buildAPIConfigTile(
                        context,
                        'OpenAI',
                        'GPT-4, GPT-3.5',
                        AppColors.openAIColor,
                        apiProvider.isProviderConfigured('OpenAI'),
                        () => _showAPIKeyDialog(context, 'OpenAI'),
                      ),
                      Divider(
                        color: isDark ? Colors.white10 : Colors.black5,
                        height: 1,
                      ),
                      _buildAPIConfigTile(
                        context,
                        'Anthropic',
                        'Claude 3, Claude 3.5',
                        AppColors.anthropicColor,
                        apiProvider.isProviderConfigured('Anthropic'),
                        () => _showAPIKeyDialog(context, 'Anthropic'),
                      ),
                      Divider(
                        color: isDark ? Colors.white10 : Colors.black5,
                        height: 1,
                      ),
                      _buildAPIConfigTile(
                        context,
                        'Google',
                        'Gemini Pro, Gemini Ultra',
                        AppColors.googleColor,
                        apiProvider.isProviderConfigured('Google'),
                        () => _showAPIKeyDialog(context, 'Google'),
                      ),
                      Divider(
                        color: isDark ? Colors.white10 : Colors.black5,
                        height: 1,
                      ),
                      _buildAPIConfigTile(
                        context,
                        'Custom Provider',
                        'Add your own API',
                        AppColors.primary,
                        apiProvider.isProviderConfigured('Custom'),
                        () => _showCustomAPIDialog(context),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Glass Effect Settings
                if (themeProvider.useGlassEffect) ...[
                  _buildSectionTitle('Glass Effect', isDark),
                  const SizedBox(height: 12),
                  GlassCard(
                    borderRadius: 20,
                    blur: 20,
                    opacity: 0.12,
                    child: Column(
                      children: [
                        _buildSliderTile(
                          context,
                          'Blur Amount',
                          themeProvider.blurAmount,
                          0,
                          50,
                          (value) => themeProvider.setBlurAmount(value),
                        ),
                        Divider(
                          color: isDark ? Colors.white10 : Colors.black5,
                          height: 1,
                        ),
                        _buildSliderTile(
                          context,
                          'Opacity',
                          themeProvider.glassOpacity,
                          0.05,
                          0.5,
                          (value) => themeProvider.setGlassOpacity(value),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],

                // About Section
                _buildSectionTitle('About', isDark),
                const SizedBox(height: 12),
                GlassCard(
                  borderRadius: 20,
                  blur: 20,
                  opacity: 0.12,
                  child: Column(
                    children: [
                      _buildInfoTile(
                        context,
                        'Version',
                        '1.0.0',
                        Icons.info_outline,
                      ),
                      Divider(
                        color: isDark ? Colors.white10 : Colors.black5,
                        height: 1,
                      ),
                      _buildInfoTile(
                        context,
                        'Privacy Policy',
                        '',
                        Icons.privacy_tip_outlined,
                        onTap: () {
                          // Open privacy policy
                        },
                      ),
                      Divider(
                        color: isDark ? Colors.white10 : Colors.black5,
                        height: 1,
                      ),
                      _buildInfoTile(
                        context,
                        'Terms of Service',
                        '',
                        Icons.description_outlined,
                        onTap: () {
                          // Open terms
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 40),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          color: isDark ? Colors.white50 : Colors.black45,
          fontSize: 12,
          fontWeight: FontWeight.w600,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildThemeSelector(BuildContext context, ThemeProvider provider) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Theme',
            style: TextStyle(
              color: isDark ? Colors.white : Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _buildThemeOption(
                context,
                Icons.light_mode,
                'Light',
                provider.appTheme == AppTheme.light,
                () => provider.setTheme(AppTheme.light),
              ),
              const SizedBox(width: 12),
              _buildThemeOption(
                context,
                Icons.dark_mode,
                'Dark',
                provider.appTheme == AppTheme.dark,
                () => provider.setTheme(AppTheme.dark),
              ),
              const SizedBox(width: 12),
              _buildThemeOption(
                context,
                Icons.settings_suggest,
                'System',
                provider.appTheme == AppTheme.system,
                () => provider.setTheme(AppTheme.system),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildThemeOption(
    BuildContext context,
    IconData icon,
    String label,
    bool isSelected,
    VoidCallback onTap,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected
                ? AppColors.primary.withOpacity(0.2)
                : (isDark ? Colors.white10 : Colors.black5),
            borderRadius: BorderRadius.circular(12),
            border: isSelected
                ? Border.all(color: AppColors.primary.withOpacity(0.5), width: 1.5)
                : null,
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: isSelected
                    ? AppColors.primary
                    : (isDark ? Colors.white60 : Colors.black54),
                size: 24,
              ),
              const SizedBox(height: 6),
              Text(
                label,
                style: TextStyle(
                  color: isSelected
                      ? AppColors.primary
                      : (isDark ? Colors.white60 : Colors.black54),
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGlassEffectToggle(BuildContext context, ThemeProvider provider) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return SwitchListTile.adaptive(
      value: provider.useGlassEffect,
      onChanged: (value) => provider.setGlassEffect(value),
      title: Text(
        'Glass Effect',
        style: TextStyle(
          color: isDark ? Colors.white : Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Text(
        'Enable frosted glass UI elements',
        style: TextStyle(
          color: isDark ? Colors.white60 : Colors.black54,
          fontSize: 13,
        ),
      ),
      secondary: Icon(
        Icons.blur_on,
        color: isDark ? Colors.white60 : Colors.black54,
      ),
      activeColor: AppColors.primary,
    );
  }

  Widget _buildAPIConfigTile(
    BuildContext context,
    String provider,
    String models,
    Color color,
    bool isConfigured,
    VoidCallback onTap,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(
          Icons.api,
          color: color,
          size: 20,
        ),
      ),
      title: Text(
        provider,
        style: TextStyle(
          color: isDark ? Colors.white : Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Text(
        models,
        style: TextStyle(
          color: isDark ? Colors.white60 : Colors.black54,
          fontSize: 13,
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: isConfigured ? Colors.green : Colors.orange,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Icon(
            Icons.arrow_forward_ios,
            color: isDark ? Colors.white40 : Colors.black38,
            size: 16,
          ),
        ],
      ),
      onTap: onTap,
    );
  }

  Widget _buildSliderTile(
    BuildContext context,
    String title,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                value.toStringAsFixed(2),
                style: TextStyle(
                  color: isDark ? Colors.white60 : Colors.black54,
                  fontSize: 13,
                ),
              ),
            ],
          ),
          Slider.adaptive(
            value: value,
            min: min,
            max: max,
            onChanged: onChanged,
            activeColor: AppColors.primary,
            inactiveColor: (isDark ? Colors.white : Colors.black).withOpacity(0.1),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoTile(
    BuildContext context,
    String title,
    String value,
    IconData icon, {
    VoidCallback? onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ListTile(
      leading: Icon(
        icon,
        color: isDark ? Colors.white60 : Colors.black54,
      ),
      title: Text(
        title,
        style: TextStyle(
          color: isDark ? Colors.white : Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: value.isNotEmpty
          ? Text(
              value,
              style: TextStyle(
                color: isDark ? Colors.white60 : Colors.black54,
                fontSize: 14,
              ),
            )
          : Icon(
              Icons.arrow_forward_ios,
              color: isDark ? Colors.white40 : Colors.black38,
              size: 16,
            ),
      onTap: onTap,
    );
  }

  void _showAPIKeyDialog(BuildContext context, String provider) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1C1C1E) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          'Configure $provider',
          style: TextStyle(
            color: isDark ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: controller,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Enter API Key',
                hintStyle: TextStyle(
                  color: isDark ? Colors.white40 : Colors.black38,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Your API key is stored securely on your device.',
              style: TextStyle(
                color: isDark ? Colors.white50 : Colors.black45,
                fontSize: 12,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: isDark ? Colors.white60 : Colors.black54,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final apiKey = controller.text.trim();
              if (apiKey.isNotEmpty) {
                final apiProvider = context.read<APIProvider>();
                switch (provider) {
                  case 'OpenAI':
                    apiProvider.setupOpenAI(apiKey);
                    break;
                  case 'Anthropic':
                    apiProvider.setupAnthropic(apiKey);
                    break;
                  case 'Google':
                    apiProvider.setupGoogle(apiKey);
                    break;
                }
              }
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showCustomAPIDialog(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final nameController = TextEditingController();
    final apiKeyController = TextEditingController();
    final baseUrlController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1C1C1E) : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          'Custom API Provider',
          style: TextStyle(
            color: isDark ? Colors.white : Colors.black,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  hintText: 'Provider Name',
                  hintStyle: TextStyle(
                    color: isDark ? Colors.white40 : Colors.black38,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: apiKeyController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'API Key',
                  hintStyle: TextStyle(
                    color: isDark ? Colors.white40 : Colors.black38,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: baseUrlController,
                decoration: InputDecoration(
                  hintText: 'Base URL',
                  hintStyle: TextStyle(
                    color: isDark ? Colors.white40 : Colors.black38,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(
                color: isDark ? Colors.white60 : Colors.black54,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              final name = nameController.text.trim();
              final apiKey = apiKeyController.text.trim();
              final baseUrl = baseUrlController.text.trim();

              if (name.isNotEmpty && apiKey.isNotEmpty && baseUrl.isNotEmpty) {
                context.read<APIProvider>().setupCustomProvider(
                      name: name,
                      apiKey: apiKey,
                      baseUrl: baseUrl,
                    );
              }
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }
}
