import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../providers/chat_provider.dart';
import '../providers/theme_provider.dart';
import '../models/message_model.dart';
import '../widgets/glass_widgets.dart';
import '../widgets/message_bubble.dart';
import '../widgets/typing_indicator.dart';
import '../theme/app_colors.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _sendMessage() {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    context.read<ChatProvider>().sendMessage(message);
    _messageController.clear();
    
    Future.delayed(const Duration(milliseconds: 100), _scrollToBottom);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final chatProvider = context.watch<ChatProvider>();
    final messages = chatProvider.currentConversation?.messages ?? [];

    return Scaffold(
      extendBodyBehindAppBar: true,
      extendBody: true,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDark
                ? [
                    const Color(0xFF0F0F0F),
                    const Color(0xFF1A1A2E),
                    const Color(0xFF16213E),
                  ]
                : [
                    const Color(0xFFF8F9FA),
                    const Color(0xFFE9ECEF),
                    const Color(0xFFDEE2E6),
                  ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Custom App Bar
              _buildAppBar(isDark),
              
              // Messages List
              Expanded(
                child: messages.isEmpty
                    ? _buildEmptyState(isDark)
                    : _buildMessagesList(messages, chatProvider.isTyping),
              ),
              
              // Input Area
              _buildInputArea(isDark),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar(bool isDark) {
    final chatProvider = context.read<ChatProvider>();
    final currentConversation = chatProvider.currentConversation;

    return GlassAppBar(
      blur: 30,
      opacity: 0.1,
      titleWidget: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            currentConversation?.title ?? 'New Chat',
            style: TextStyle(
              color: isDark ? Colors.white : Colors.black,
              fontSize: 17,
              fontWeight: FontWeight.w600,
              fontFamily: 'SF Pro Display',
            ),
          ),
          const SizedBox(height: 2),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: AppColors.success,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                currentConversation?.model.displayName ?? 'GPT-4 Turbo',
                style: TextStyle(
                  color: isDark ? Colors.white60 : Colors.black54,
                  fontSize: 12,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
      leading: GlassButton(
        onPressed: () => _showConversationsDrawer(context),
        borderRadius: 12,
        blur: 15,
        opacity: 0.1,
        padding: const EdgeInsets.all(10),
        child: Icon(
          Icons.menu_rounded,
          color: isDark ? Colors.white70 : Colors.black54,
          size: 22,
        ),
      ),
      actions: [
        GlassButton(
          onPressed: () => _showModelSelector(context),
          borderRadius: 12,
          blur: 15,
          opacity: 0.1,
          padding: const EdgeInsets.all(10),
          child: Icon(
            Icons.auto_awesome,
            color: isDark ? Colors.white70 : Colors.black54,
            size: 22,
          ),
        ),
        const SizedBox(width: 8),
        GlassButton(
          onPressed: () => _showMoreOptions(context),
          borderRadius: 12,
          blur: 15,
          opacity: 0.1,
          padding: const EdgeInsets.all(10),
          child: Icon(
            Icons.more_vert,
            color: isDark ? Colors.white70 : Colors.black54,
            size: 22,
          ),
        ),
      ],
    );
  }

  Widget _buildMessagesList(List<MessageModel> messages, bool isTyping) {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: messages.length + (isTyping ? 1 : 0),
      itemBuilder: (context, index) {
        if (index == messages.length && isTyping) {
          return const TypingIndicator()
              .animate()
              .fadeIn(duration: 300.ms)
              .slideY(begin: 0.2, end: 0);
        }

        final message = messages[index];
        final isLastMessage = index == messages.length - 1;

        return MessageBubble(
          message: message,
          isLastMessage: isLastMessage,
        )
            .animate()
            .fadeIn(duration: 300.ms, delay: (index * 50).ms)
            .slideY(begin: 0.1, end: 0);
      },
    );
  }

  Widget _buildEmptyState(bool isDark) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GlassContainer(
            width: 120,
            height: 120,
            borderRadius: 30,
            blur: 25,
            opacity: 0.15,
            child: Icon(
              Icons.chat_bubble_outline,
              size: 50,
              color: isDark ? Colors.white40 : Colors.black26,
            ),
          )
              .animate()
              .fadeIn(duration: 600.ms)
              .scale(begin: const Offset(0.8, 0.8), end: const Offset(1, 1)),
          const SizedBox(height: 32),
          Text(
            'Start a Conversation',
            style: TextStyle(
              color: isDark ? Colors.white70 : Colors.black54,
              fontSize: 22,
              fontWeight: FontWeight.w600,
              fontFamily: 'SF Pro Display',
            ),
          )
              .animate()
              .fadeIn(duration: 600.ms, delay: 200.ms)
              .slideY(begin: 0.2, end: 0),
          const SizedBox(height: 12),
          Text(
            'Ask me anything! I\'m here to help.',
            style: TextStyle(
              color: isDark ? Colors.white40 : Colors.black38,
              fontSize: 15,
              fontFamily: 'SF Pro Text',
            ),
          )
              .animate()
              .fadeIn(duration: 600.ms, delay: 300.ms)
              .slideY(begin: 0.2, end: 0),
          const SizedBox(height: 40),
          _buildQuickPrompts(isDark),
        ],
      ),
    );
  }

  Widget _buildQuickPrompts(bool isDark) {
    final prompts = [
      'Explain quantum computing',
      'Write a poem about AI',
      'Help me debug my code',
      'Suggest dinner ideas',
    ];

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      alignment: WrapAlignment.center,
      children: prompts.map((prompt) {
        return GlassButton(
          onPressed: () {
            _messageController.text = prompt;
            _sendMessage();
          },
          borderRadius: 20,
          blur: 15,
          opacity: 0.1,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Text(
            prompt,
            style: TextStyle(
              color: isDark ? Colors.white70 : Colors.black54,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        )
            .animate()
            .fadeIn(duration: 400.ms, delay: (prompts.indexOf(prompt) * 100 + 400).ms)
            .scale(begin: const Offset(0.9, 0.9), end: const Offset(1, 1));
      }).toList(),
    );
  }

  Widget _buildInputArea(bool isDark) {
    return GlassContainer(
      margin: const EdgeInsets.all(16),
      borderRadius: 28,
      blur: 30,
      opacity: 0.15,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        children: [
          GlassButton(
            onPressed: () => _showAttachmentOptions(context),
            borderRadius: 20,
            blur: 10,
            opacity: 0.1,
            padding: const EdgeInsets.all(12),
            child: Icon(
              Icons.add_circle_outline,
              color: isDark ? Colors.white60 : Colors.black45,
              size: 24,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: GlassInputField(
              controller: _messageController,
              focusNode: _focusNode,
              hintText: 'Message...',
              borderRadius: 20,
              blur: 15,
              opacity: 0.1,
              maxLines: 5,
              minLines: 1,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _sendMessage(),
            ),
          ),
          const SizedBox(width: 8),
          AnimatedBuilder(
            animation: _messageController,
            builder: (context, child) {
              final hasText = _messageController.text.trim().isNotEmpty;
              return GlassButton(
                onPressed: hasText ? _sendMessage : null,
                borderRadius: 20,
                blur: 10,
                opacity: hasText ? 0.3 : 0.1,
                gradient: hasText
                    ? const LinearGradient(
                        colors: AppColors.primaryGradient,
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
                padding: const EdgeInsets.all(12),
                child: Icon(
                  Icons.arrow_upward,
                  color: hasText ? Colors.white : (isDark ? Colors.white40 : Colors.black38),
                  size: 24,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showConversationsDrawer(BuildContext context) {
    // Show conversations drawer
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const ConversationsDrawer(),
    );
  }

  void _showModelSelector(BuildContext context) {
    // Show model selector
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const ModelSelectorSheet(),
    );
  }

  void _showMoreOptions(BuildContext context) {
    // Show more options
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => const MoreOptionsSheet(),
    );
  }

  void _showAttachmentOptions(BuildContext context) {
    // Show attachment options
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => const AttachmentOptionsSheet(),
    );
  }
}

// Drawer and Sheet widgets will be defined in separate files
class ConversationsDrawer extends StatelessWidget {
  const ConversationsDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink(); // Placeholder
  }
}

class ModelSelectorSheet extends StatelessWidget {
  const ModelSelectorSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink(); // Placeholder
  }
}

class MoreOptionsSheet extends StatelessWidget {
  const MoreOptionsSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink(); // Placeholder
  }
}

class AttachmentOptionsSheet extends StatelessWidget {
  const AttachmentOptionsSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink(); // Placeholder
  }
}
