import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/chat_model.dart';

abstract class AIProvider {
  Future<String> sendMessage({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  });
  
  Stream<String> sendMessageStream({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  });
}

class OpenAIProvider implements AIProvider {
  final String apiKey;
  final String baseUrl;

  OpenAIProvider({
    required this.apiKey,
    this.baseUrl = 'https://api.openai.com/v1',
  });

  @override
  Future<String> sendMessage({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async {
    final requestMessages = <Map<String, String>>[];
    
    if (systemPrompt != null && systemPrompt.isNotEmpty) {
      requestMessages.add({'role': 'system', 'content': systemPrompt});
    }
    
    requestMessages.addAll(messages);

    final response = await http.post(
      Uri.parse('$baseUrl/chat/completions'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': model.modelId,
        'messages': requestMessages,
        'temperature': 0.7,
        'max_tokens': 2000,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'];
    } else {
      throw Exception('OpenAI API Error: ${response.statusCode} - ${response.body}');
    }
  }

  @override
  Stream<String> sendMessageStream({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async* {
    final request = http.Request(
      'POST',
      Uri.parse('$baseUrl/chat/completions'),
    );

    final requestMessages = <Map<String, String>>[];
    if (systemPrompt != null && systemPrompt.isNotEmpty) {
      requestMessages.add({'role': 'system', 'content': systemPrompt});
    }
    requestMessages.addAll(messages);

    request.headers.addAll({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $apiKey',
    });

    request.body = jsonEncode({
      'model': model.modelId,
      'messages': requestMessages,
      'temperature': 0.7,
      'max_tokens': 2000,
      'stream': true,
    });

    final response = await request.send();

    if (response.statusCode != 200) {
      throw Exception('OpenAI API Error: ${response.statusCode}');
    }

    await for (final chunk in response.stream.transform(utf8.decoder)) {
      final lines = chunk.split('\n');
      for (final line in lines) {
        if (line.startsWith('data: ')) {
          final data = line.substring(6);
          if (data == '[DONE]') return;
          
          try {
            final jsonData = jsonDecode(data);
            final delta = jsonData['choices']?[0]?['delta']?['content'];
            if (delta != null) {
              yield delta;
            }
          } catch (e) {
            debugPrint('Error parsing stream: $e');
          }
        }
      }
    }
  }
}

class AnthropicProvider implements AIProvider {
  final String apiKey;
  final String baseUrl;

  AnthropicProvider({
    required this.apiKey,
    this.baseUrl = 'https://api.anthropic.com/v1',
  });

  @override
  Future<String> sendMessage({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/messages'),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': model.modelId,
        'max_tokens': 2000,
        'system': systemPrompt,
        'messages': messages,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['content'][0]['text'];
    } else {
      throw Exception('Anthropic API Error: ${response.statusCode} - ${response.body}');
    }
  }

  @override
  Stream<String> sendMessageStream({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async* {
    // Anthropic streaming implementation
    // Similar to OpenAI but with Anthropic-specific format
    yield* Stream.fromFuture(
      sendMessage(messages: messages, model: model, systemPrompt: systemPrompt),
    );
  }
}

class GoogleProvider implements AIProvider {
  final String apiKey;
  final String baseUrl;

  GoogleProvider({
    required this.apiKey,
    this.baseUrl = 'https://generativelanguage.googleapis.com/v1',
  });

  @override
  Future<String> sendMessage({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async {
    final contents = messages.map((m) => {
      'role': m['role'] == 'user' ? 'user' : 'model',
      'parts': [{'text': m['content']}],
    }).toList();

    final response = await http.post(
      Uri.parse('$baseUrl/models/${model.modelId}:generateContent?key=$apiKey'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'contents': contents,
        'systemInstruction': systemPrompt != null
            ? {'parts': [{'text': systemPrompt}]}
            : null,
        'generationConfig': {
          'temperature': 0.7,
          'maxOutputTokens': 2000,
        },
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['candidates'][0]['content']['parts'][0]['text'];
    } else {
      throw Exception('Google API Error: ${response.statusCode} - ${response.body}');
    }
  }

  @override
  Stream<String> sendMessageStream({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async* {
    yield* Stream.fromFuture(
      sendMessage(messages: messages, model: model, systemPrompt: systemPrompt),
    );
  }
}

class AIService {
  AIProvider? _currentProvider;
  String? _apiKey;

  void configureProvider({
    required String provider,
    required String apiKey,
    String? baseUrl,
  }) {
    _apiKey = apiKey;
    
    switch (provider) {
      case 'OpenAI':
        _currentProvider = OpenAIProvider(
          apiKey: apiKey,
          baseUrl: baseUrl ?? 'https://api.openai.com/v1',
        );
        break;
      case 'Anthropic':
        _currentProvider = AnthropicProvider(
          apiKey: apiKey,
          baseUrl: baseUrl ?? 'https://api.anthropic.com/v1',
        );
        break;
      case 'Google':
        _currentProvider = GoogleProvider(
          apiKey: apiKey,
          baseUrl: baseUrl ?? 'https://generativelanguage.googleapis.com/v1',
        );
        break;
      default:
        throw Exception('Unsupported provider: $provider');
    }
  }

  Future<String> sendMessage({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async {
    if (_currentProvider == null) {
      // Return mock response for demo
      await Future.delayed(const Duration(seconds: 1));
      return _getMockResponse(messages.lastOrNull?['content'] ?? '');
    }

    return _currentProvider!.sendMessage(
      messages: messages,
      model: model,
      systemPrompt: systemPrompt,
    );
  }

  Stream<String> sendMessageStream({
    required List<Map<String, String>> messages,
    required ChatModel model,
    String? systemPrompt,
  }) async* {
    if (_currentProvider == null) {
      // Return mock streaming response
      final response = _getMockResponse(messages.lastOrNull?['content'] ?? '');
      final words = response.split(' ');
      for (final word in words) {
        await Future.delayed(const Duration(milliseconds: 50));
        yield '$word ';
      }
      return;
    }

    yield* _currentProvider!.sendMessageStream(
      messages: messages,
      model: model,
      systemPrompt: systemPrompt,
    );
  }

  String _getMockResponse(String userMessage) {
    final responses = [
      'I understand your question about "$userMessage". This is a fascinating topic! Let me provide you with a comprehensive answer...',
      'Great question! Here\'s what I know about that:\n\n1. First, it\'s important to understand the context\n2. Then, we can explore the details\n3. Finally, we\'ll reach a conclusion',
      'I\'d be happy to help with that! Based on my knowledge, I can tell you that this involves several key factors...',
      'That\'s an interesting point! From my perspective, I would approach this by analyzing the main components and their relationships...',
      'Thank you for sharing that! Here\'s my analysis:\n\n• Key insight 1: The fundamentals are solid\n• Key insight 2: There are multiple approaches\n• Key insight 3: Results may vary based on context',
    ];
    
    return responses[userMessage.length % responses.length];
  }

  bool get isConfigured => _currentProvider != null && _apiKey != null;
}
