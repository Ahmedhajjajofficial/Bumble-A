import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors
  static const Color primary = Color(0xFF007AFF);
  static const Color primaryLight = Color(0xFF5AC8FA);
  static const Color primaryDark = Color(0xFF0051D5);
  
  // Secondary Colors
  static const Color secondary = Color(0xFF5856D6);
  static const Color accent = Color(0xFFFF9500);
  
  // Semantic Colors
  static const Color success = Color(0xFF34C759);
  static const Color warning = Color(0xFFFF9500);
  static const Color error = Color(0xFFFF3B30);
  static const Color info = Color(0xFF5AC8FA);
  
  // Light Theme Colors
  static const Color backgroundLight = Color(0xFFF2F2F7);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color textPrimaryLight = Color(0xFF000000);
  static const Color textSecondaryLight = Color(0xFF8E8E93);
  static const Color dividerLight = Color(0xFFC6C6C8);
  
  // Dark Theme Colors
  static const Color backgroundDark = Color(0xFF000000);
  static const Color surfaceDark = Color(0xFF1C1C1E);
  static const Color textPrimaryDark = Color(0xFFFFFFFF);
  static const Color textSecondaryDark = Color(0xFF8E8E93);
  static const Color dividerDark = Color(0xFF38383A);
  
  // Glass Effect Colors (Light)
  static const Color glassLight = Color(0x80FFFFFF);
  static const Color glassBorderLight = Color(0x40FFFFFF);
  static const Color glassShadowLight = Color(0x1A000000);
  
  // Glass Effect Colors (Dark)
  static const Color glassDark = Color(0x801C1C1E);
  static const Color glassBorderDark = Color(0x40FFFFFF);
  static const Color glassShadowDark = Color(0x40000000);
  
  // Gradient Colors
  static const List<Color> primaryGradient = [
    Color(0xFF007AFF),
    Color(0xFF5856D6),
  ];
  
  static const List<Color> accentGradient = [
    Color(0xFFFF9500),
    Color(0xFFFF6B00),
  ];
  
  static const List<Color> glassGradientLight = [
    Color(0x40FFFFFF),
    Color(0x20FFFFFF),
  ];
  
  static const List<Color> glassGradientDark = [
    Color(0x40FFFFFF),
    Color(0x10FFFFFF),
  ];
  
  // AI Model Colors
  static const Color openAIColor = Color(0xFF10A37F);
  static const Color anthropicColor = Color(0xFFCC785C);
  static const Color googleColor = Color(0xFF4285F4);
  static const Color metaColor = Color(0xFF0668E1);
  static const Color mistralColor = Color(0xFFFD6E00);
  
  // Message Bubble Colors (Light)
  static const Color userBubbleLight = Color(0xFF007AFF);
  static const Color aiBubbleLight = Color(0xFFE5E5EA);
  static const Color userTextLight = Color(0xFFFFFFFF);
  static const Color aiTextLight = Color(0xFF000000);
  
  // Message Bubble Colors (Dark)
  static const Color userBubbleDark = Color(0xFF0A84FF);
  static const Color aiBubbleDark = Color(0xFF1C1C1E);
  static const Color userTextDark = Color(0xFFFFFFFF);
  static const Color aiTextDark = Color(0xFFFFFFFF);
  
  // Helper method to get color with opacity
  static Color withOpacity(Color color, double opacity) {
    return color.withOpacity(opacity);
  }
  
  // Helper method to get adaptive color
  static Color adaptive(BuildContext context, Color lightColor, Color darkColor) {
    final brightness = Theme.of(context).brightness;
    return brightness == Brightness.dark ? darkColor : lightColor;
  }
  
  // Get glass color based on theme
  static Color glassColor(BuildContext context) {
    return adaptive(context, glassLight, glassDark);
  }
  
  // Get glass border color based on theme
  static Color glassBorderColor(BuildContext context) {
    return adaptive(context, glassBorderLight, glassBorderDark);
  }
  
  // Get surface color based on theme
  static Color surfaceColor(BuildContext context) {
    return adaptive(context, surfaceLight, surfaceDark);
  }
  
  // Get background color based on theme
  static Color backgroundColor(BuildContext context) {
    return adaptive(context, backgroundLight, backgroundDark);
  }
  
  // Get text primary color based on theme
  static Color textPrimary(BuildContext context) {
    return adaptive(context, textPrimaryLight, textPrimaryDark);
  }
  
  // Get text secondary color based on theme
  static Color textSecondary(BuildContext context) {
    return adaptive(context, textSecondaryLight, textSecondaryDark);
  }
  
  // Get model color
  static Color getModelColor(String provider) {
    switch (provider) {
      case 'OpenAI':
        return openAIColor;
      case 'Anthropic':
        return anthropicColor;
      case 'Google':
        return googleColor;
      case 'Meta':
        return metaColor;
      case 'Mistral AI':
        return mistralColor;
      default:
        return primary;
    }
  }
}
