import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class GlassContainer extends StatelessWidget {
  final Widget child;
  final double? width;
  final double? height;
  final double borderRadius;
  final double blur;
  final double opacity;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final BoxBorder? border;
  final List<BoxShadow>? boxShadow;
  final Gradient? gradient;
  final AlignmentGeometry? alignment;

  const GlassContainer({
    super.key,
    required this.child,
    this.width,
    this.height,
    this.borderRadius = 20,
    this.blur = 20,
    this.opacity = 0.15,
    this.padding,
    this.margin,
    this.border,
    this.boxShadow,
    this.gradient,
    this.alignment,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final baseColor = isDark ? Colors.black : Colors.white;

    return Container(
      width: width,
      height: height,
      margin: margin,
      alignment: alignment,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: baseColor.withOpacity(opacity),
              borderRadius: BorderRadius.circular(borderRadius),
              border: border ?? Border.all(
                color: isDark 
                    ? Colors.white.withOpacity(0.1)
                    : Colors.white.withOpacity(0.5),
                width: 1,
              ),
              boxShadow: boxShadow ?? [
                BoxShadow(
                  color: isDark 
                      ? Colors.black.withOpacity(0.3)
                      : Colors.black.withOpacity(0.05),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
              gradient: gradient,
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final double borderRadius;
  final double blur;
  final double opacity;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;
  final Color? accentColor;

  const GlassCard({
    super.key,
    required this.child,
    this.borderRadius = 24,
    this.blur = 25,
    this.opacity = 0.12,
    this.padding,
    this.onTap,
    this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: GlassContainer(
        borderRadius: borderRadius,
        blur: blur,
        opacity: opacity,
        padding: padding ?? const EdgeInsets.all(20),
        border: Border.all(
          color: accentColor?.withOpacity(0.3) ?? 
                 (isDark ? Colors.white.withOpacity(0.08) : Colors.white.withOpacity(0.6)),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: isDark 
                ? Colors.black.withOpacity(0.4)
                : Colors.black.withOpacity(0.08),
            blurRadius: 30,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: accentColor?.withOpacity(0.1) ?? Colors.transparent,
            blurRadius: 40,
            offset: const Offset(0, 5),
          ),
        ],
        child: child,
      ),
    );
  }
}

class GlassButton extends StatelessWidget {
  final Widget child;
  final VoidCallback onPressed;
  final double borderRadius;
  final double blur;
  final double opacity;
  final EdgeInsetsGeometry? padding;
  final Color? backgroundColor;
  final Gradient? gradient;
  final double? width;
  final double? height;

  const GlassButton({
    super.key,
    required this.child,
    required this.onPressed,
    this.borderRadius = 16,
    this.blur = 15,
    this.opacity = 0.2,
    this.padding,
    this.backgroundColor,
    this.gradient,
    this.width,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onPressed,
      child: GlassContainer(
        width: width,
        height: height,
        borderRadius: borderRadius,
        blur: blur,
        opacity: opacity,
        padding: padding ?? const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        gradient: gradient,
        border: Border.all(
          color: isDark 
              ? Colors.white.withOpacity(0.15)
              : Colors.white.withOpacity(0.7),
          width: 1,
        ),
        child: child,
      ),
    );
  }
}

class GlassInputField extends StatelessWidget {
  final TextEditingController? controller;
  final String? hintText;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final VoidCallback? onSubmitted;
  final ValueChanged<String>? onChanged;
  final bool autofocus;
  final FocusNode? focusNode;
  final TextInputAction? textInputAction;
  final int? maxLines;
  final int? minLines;
  final double borderRadius;
  final double blur;
  final double opacity;

  const GlassInputField({
    super.key,
    this.controller,
    this.hintText,
    this.prefixIcon,
    this.suffixIcon,
    this.onSubmitted,
    this.onChanged,
    this.autofocus = false,
    this.focusNode,
    this.textInputAction,
    this.maxLines = 1,
    this.minLines,
    this.borderRadius = 20,
    this.blur = 20,
    this.opacity = 0.15,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black;
    final hintColor = isDark ? Colors.white54 : Colors.black38;

    return GlassContainer(
      borderRadius: borderRadius,
      blur: blur,
      opacity: opacity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Row(
        children: [
          if (prefixIcon != null) ...[
            prefixIcon!,
            const SizedBox(width: 12),
          ],
          Expanded(
            child: TextField(
              controller: controller,
              focusNode: focusNode,
              autofocus: autofocus,
              onChanged: onChanged,
              onSubmitted: onSubmitted != null ? (_) => onSubmitted!() : null,
              textInputAction: textInputAction,
              maxLines: maxLines,
              minLines: minLines,
              style: TextStyle(
                color: textColor,
                fontSize: 16,
                fontFamily: 'SF Pro Text',
              ),
              decoration: InputDecoration(
                hintText: hintText,
                hintStyle: TextStyle(
                  color: hintColor,
                  fontSize: 16,
                  fontFamily: 'SF Pro Text',
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          if (suffixIcon != null) ...[
            const SizedBox(width: 12),
            suffixIcon!,
          ],
        ],
      ),
    );
  }
}

class GlassAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final Widget? titleWidget;
  final List<Widget>? actions;
  final Widget? leading;
  final double blur;
  final double opacity;
  final double height;
  final bool centerTitle;

  const GlassAppBar({
    super.key,
    this.title,
    this.titleWidget,
    this.actions,
    this.leading,
    this.blur = 25,
    this.opacity = 0.15,
    this.height = kToolbarHeight + 16,
    this.centerTitle = true,
  });

  @override
  Size get preferredSize => Size.fromHeight(height);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : Colors.black;

    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          height: height,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: (isDark ? Colors.black : Colors.white).withOpacity(opacity),
            border: Border(
              bottom: BorderSide(
                color: isDark 
                    ? Colors.white.withOpacity(0.05)
                    : Colors.black.withOpacity(0.05),
                width: 0.5,
              ),
            ),
          ),
          child: SafeArea(
            child: Row(
              children: [
                if (leading != null) leading!,
                if (leading != null) const SizedBox(width: 8),
                Expanded(
                  child: centerTitle
                      ? Center(child: titleWidget ?? _buildTitle(textColor))
                      : titleWidget ?? _buildTitle(textColor),
                ),
                if (actions != null) ...[
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: actions!,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTitle(Color textColor) {
    if (title == null) return const SizedBox.shrink();
    return Text(
      title!,
      style: TextStyle(
        color: textColor,
        fontSize: 17,
        fontWeight: FontWeight.w600,
        fontFamily: 'SF Pro Display',
        letterSpacing: -0.3,
      ),
    );
  }
}

class GlassBottomBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final List<GlassBottomBarItem> items;
  final double blur;
  final double opacity;
  final double height;

  const GlassBottomBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
    this.blur = 25,
    this.opacity = 0.2,
    this.height = 80,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          height: height,
          decoration: BoxDecoration(
            color: (isDark ? Colors.black : Colors.white).withOpacity(opacity),
            border: Border(
              top: BorderSide(
                color: isDark 
                    ? Colors.white.withOpacity(0.05)
                    : Colors.black.withOpacity(0.05),
                width: 0.5,
              ),
            ),
          ),
          child: SafeArea(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: List.generate(items.length, (index) {
                final item = items[index];
                final isSelected = index == currentIndex;
                
                return GestureDetector(
                  onTap: () => onTap(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected 
                          ? AppColors.primary.withOpacity(0.15)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          isSelected ? item.selectedIcon : item.icon,
                          color: isSelected 
                              ? AppColors.primary
                              : (isDark ? Colors.white60 : Colors.black54),
                          size: 24,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.label,
                          style: TextStyle(
                            color: isSelected 
                                ? AppColors.primary
                                : (isDark ? Colors.white60 : Colors.black54),
                            fontSize: 11,
                            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                            fontFamily: 'SF Pro Text',
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
      ),
    );
  }
}

class GlassBottomBarItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;

  const GlassBottomBarItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
}

class GlassAvatar extends StatelessWidget {
  final String? imageUrl;
  final IconData? icon;
  final double size;
  final double blur;
  final double opacity;
  final Color? accentColor;

  const GlassAvatar({
    super.key,
    this.imageUrl,
    this.icon,
    this.size = 48,
    this.blur = 15,
    this.opacity = 0.2,
    this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GlassContainer(
      width: size,
      height: size,
      borderRadius: size / 2,
      blur: blur,
      opacity: opacity,
      border: Border.all(
        color: accentColor?.withOpacity(0.4) ?? 
               (isDark ? Colors.white.withOpacity(0.2) : Colors.white.withOpacity(0.8)),
        width: 2,
      ),
      child: ClipOval(
        child: imageUrl != null
            ? Image.network(
                imageUrl!,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _buildFallbackIcon(isDark),
              )
            : _buildFallbackIcon(isDark),
      ),
    );
  }

  Widget _buildFallbackIcon(bool isDark) {
    return Center(
      child: Icon(
        icon ?? Icons.person,
        color: isDark ? Colors.white70 : Colors.black54,
        size: size * 0.4,
      ),
    );
  }
}
