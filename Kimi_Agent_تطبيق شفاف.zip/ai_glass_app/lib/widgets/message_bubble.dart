import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/message_model.dart';
import 'glass_widgets.dart';
import '../theme/app_colors.dart';

class MessageBubble extends StatelessWidget {
  final MessageModel message;
  final bool isLastMessage;

  const MessageBubble({
    super.key,
    required this.message,
    this.isLastMessage = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isUser = message.isUser;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(
          bottom: 12,
          left: isUser ? 60 : 0,
          right: isUser ? 0 : 60,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (!isUser) _buildAvatar(isDark),
            if (!isUser) const SizedBox(width: 8),
            Flexible(
              child: GestureDetector(
                onLongPress: () => _showMessageOptions(context),
                child: _buildBubbleContent(isDark, isUser),
              ),
            ),
            if (isUser) const SizedBox(width: 8),
            if (isUser) _buildAvatar(isDark, isUser: true),
          ],
        ),
      ),
    );
  }

  Widget _buildAvatar(bool isDark, {bool isUser = false}) {
    return GlassAvatar(
      size: 32,
      blur: 15,
      opacity: 0.15,
      icon: isUser ? Icons.person : Icons.smart_toy,
      accentColor: isUser ? AppColors.primary : AppColors.secondary,
    );
  }

  Widget _buildBubbleContent(bool isDark, bool isUser) {
    switch (message.type) {
      case MessageType.thinking:
        return _buildThinkingBubble(isDark);
      case MessageType.image:
        return _buildImageBubble(isDark, isUser);
      case MessageType.file:
        return _buildFileBubble(isDark, isUser);
      case MessageType.audio:
        return _buildAudioBubble(isDark, isUser);
      default:
        return _buildTextBubble(isDark, isUser);
    }
  }

  Widget _buildTextBubble(bool isDark, bool isUser) {
    final bubbleColor = isUser
        ? (isDark ? AppColors.userBubbleDark : AppColors.userBubbleLight)
        : (isDark ? AppColors.aiBubbleDark : AppColors.aiBubbleLight);
    
    final textColor = isUser
        ? (isDark ? AppColors.userTextDark : AppColors.userTextLight)
        : (isDark ? AppColors.aiTextDark : AppColors.aiTextLight);

    return GlassContainer(
      borderRadius: isUser ? 20 : 20,
      blur: isUser ? 15 : 25,
      opacity: isUser ? 0.25 : 0.12,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      gradient: isUser
          ? LinearGradient(
              colors: [
                AppColors.primary.withOpacity(0.8),
                AppColors.secondary.withOpacity(0.6),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            )
          : null,
      child: SelectableText(
        message.content,
        style: TextStyle(
          color: isUser ? Colors.white : textColor,
          fontSize: 15,
          height: 1.5,
          fontFamily: 'SF Pro Text',
        ),
      ),
    );
  }

  Widget _buildThinkingBubble(bool isDark) {
    return GlassContainer(
      borderRadius: 20,
      blur: 25,
      opacity: 0.1,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(
                isDark ? Colors.white60 : Colors.black45,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'Thinking...',
            style: TextStyle(
              color: isDark ? Colors.white60 : Colors.black54,
              fontSize: 14,
              fontFamily: 'SF Pro Text',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageBubble(bool isDark, bool isUser) {
    return GlassContainer(
      borderRadius: 20,
      blur: 20,
      opacity: 0.15,
      padding: const EdgeInsets.all(8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.network(
          message.imageUrl ?? '',
          fit: BoxFit.cover,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return Container(
              width: 200,
              height: 150,
              color: isDark ? Colors.white10 : Colors.black5,
              child: Center(
                child: CircularProgressIndicator(
                  value: loadingProgress.expectedTotalBytes != null
                      ? loadingProgress.cumulativeBytesLoaded /
                          loadingProgress.expectedTotalBytes!
                      : null,
                ),
              ),
            );
          },
          errorBuilder: (_, __, ___) => Container(
            width: 200,
            height: 150,
            color: isDark ? Colors.white10 : Colors.black5,
            child: Icon(
              Icons.broken_image,
              color: isDark ? Colors.white40 : Colors.black38,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFileBubble(bool isDark, bool isUser) {
    return GlassContainer(
      borderRadius: 16,
      blur: 20,
      opacity: 0.15,
      padding: const EdgeInsets.all(12),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.insert_drive_file,
              color: AppColors.primary,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                message.fileName ?? 'File',
                style: TextStyle(
                  color: isDark ? Colors.white : Colors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                _formatFileSize(message.fileSize ?? 0),
                style: TextStyle(
                  color: isDark ? Colors.white60 : Colors.black54,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAudioBubble(bool isDark, bool isUser) {
    return GlassContainer(
      borderRadius: 24,
      blur: 20,
      opacity: 0.15,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.play_circle_filled,
            color: isDark ? Colors.white70 : Colors.black54,
            size: 32,
          ),
          const SizedBox(width: 12),
          Container(
            width: 100,
            height: 30,
            decoration: BoxDecoration(
              color: isDark ? Colors.white10 : Colors.black5,
              borderRadius: BorderRadius.circular(4),
            ),
            child: CustomPaint(
              painter: WaveformPainter(
                color: isDark ? Colors.white60 : Colors.black45,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Text(
            _formatDuration(message.audioDuration ?? Duration.zero),
            style: TextStyle(
              color: isDark ? Colors.white60 : Colors.black54,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  String _formatDuration(Duration duration) {
    final minutes = duration.inMinutes;
    final seconds = duration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  void _showMessageOptions(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => GlassContainer(
        borderRadius: 24,
        blur: 30,
        opacity: 0.2,
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildOptionTile(
              icon: Icons.copy,
              title: 'Copy',
              onTap: () {
                Clipboard.setData(ClipboardData(text: message.content));
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Copied to clipboard'),
                    behavior: SnackBarBehavior.floating,
                    backgroundColor: isDark ? Colors.white24 : Colors.black87,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                );
              },
            ),
            _buildOptionTile(
              icon: Icons.share,
              title: 'Share',
              onTap: () {
                Navigator.pop(context);
                // Implement share functionality
              },
            ),
            if (!message.isUser)
              _buildOptionTile(
                icon: Icons.thumb_up_outlined,
                title: 'Helpful',
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            if (!message.isUser)
              _buildOptionTile(
                icon: Icons.thumb_down_outlined,
                title: 'Not helpful',
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            _buildOptionTile(
              icon: Icons.delete_outline,
              title: 'Delete',
              isDestructive: true,
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return ListTile(
      leading: Icon(
        icon,
        color: isDestructive
            ? AppColors.error
            : (isDark ? Colors.white70 : Colors.black54),
      ),
      title: Text(
        title,
        style: TextStyle(
          color: isDestructive
              ? AppColors.error
              : (isDark ? Colors.white : Colors.black),
          fontSize: 16,
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
    );
  }
}

class WaveformPainter extends CustomPainter {
  final Color color;

  WaveformPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    final random = List.generate(20, (_) => 0.3 + (0.7 * (DateTime.now().millisecond % 100) / 100));
    
    final barWidth = size.width / random.length;
    final gap = barWidth * 0.3;
    
    for (int i = 0; i < random.length; i++) {
      final height = size.height * random[i];
      final x = i * barWidth + gap / 2;
      final y = (size.height - height) / 2;
      
      canvas.drawLine(
        Offset(x + barWidth / 2 - gap / 2, y),
        Offset(x + barWidth / 2 - gap / 2, y + height),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
