import 'package:uuid/uuid.dart';
import 'message_model.dart';

enum ChatModel {
  gpt4('GPT-4', 'OpenAI', 'gpt-4'),
  gpt4Turbo('GPT-4 Turbo', 'OpenAI', 'gpt-4-turbo-preview'),
  gpt35Turbo('GPT-3.5 Turbo', 'OpenAI', 'gpt-3.5-turbo'),
  claude3('Claude 3', 'Anthropic', 'claude-3-opus-20240229'),
  claude35('Claude 3.5', 'Anthropic', 'claude-3-5-sonnet-20241022'),
  geminiPro('Gemini Pro', 'Google', 'gemini-pro'),
  geminiUltra('Gemini Ultra', 'Google', 'gemini-ultra'),
  llama3('Llama 3', 'Meta', 'llama-3-70b-instruct'),
  mistral('Mistral', 'Mistral AI', 'mistral-large-latest'),
  custom('Custom Model', 'Custom', 'custom');

  final String displayName;
  final String provider;
  final String modelId;

  const ChatModel(this.displayName, this.provider, this.modelId);
}

class ConversationModel {
  final String id;
  final String title;
  final List<MessageModel> messages;
  final ChatModel model;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPinned;
  final String? systemPrompt;
  final Map<String, dynamic>? settings;

  ConversationModel({
    String? id,
    required this.title,
    List<MessageModel>? messages,
    this.model = ChatModel.gpt4Turbo,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.isPinned = false,
    this.systemPrompt,
    this.settings,
  })  : id = id ?? const Uuid().v4(),
        messages = messages ?? [],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  String get lastMessagePreview {
    if (messages.isEmpty) return 'No messages yet';
    final lastMsg = messages.last;
    if (lastMsg.content.length > 50) {
      return '${lastMsg.content.substring(0, 50)}...';
    }
    return lastMsg.content;
  }

  int get messageCount => messages.length;

  ConversationModel copyWith({
    String? title,
    List<MessageModel>? messages,
    ChatModel? model,
    bool? isPinned,
    String? systemPrompt,
    Map<String, dynamic>? settings,
  }) {
    return ConversationModel(
      id: id,
      title: title ?? this.title,
      messages: messages ?? this.messages,
      model: model ?? this.model,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      isPinned: isPinned ?? this.isPinned,
      systemPrompt: systemPrompt ?? this.systemPrompt,
      settings: settings ?? this.settings,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'messages': messages.map((m) => m.toJson()).toList(),
      'model': model.name,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'isPinned': isPinned,
      'systemPrompt': systemPrompt,
      'settings': settings,
    };
  }

  factory ConversationModel.fromJson(Map<String, dynamic> json) {
    return ConversationModel(
      id: json['id'],
      title: json['title'],
      messages: (json['messages'] as List)
          .map((m) => MessageModel.fromJson(m))
          .toList(),
      model: ChatModel.values.byName(json['model']),
      createdAt: DateTime.parse(json['createdAt']),
      updatedAt: DateTime.parse(json['updatedAt']),
      isPinned: json['isPinned'] ?? false,
      systemPrompt: json['systemPrompt'],
      settings: json['settings'],
    );
  }
}
