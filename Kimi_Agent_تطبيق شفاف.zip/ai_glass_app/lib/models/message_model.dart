import 'package:uuid/uuid.dart';

enum MessageType {
  text,
  image,
  audio,
  file,
  thinking,
}

enum MessageStatus {
  sending,
  sent,
  delivered,
  error,
}

class MessageModel {
  final String id;
  final String content;
  final MessageType type;
  final bool isUser;
  final DateTime timestamp;
  final MessageStatus status;
  final String? imageUrl;
  final String? fileName;
  final int? fileSize;
  final Duration? audioDuration;
  final List<String>? thinkingSteps;
  final Map<String, dynamic>? metadata;

  MessageModel({
    String? id,
    required this.content,
    this.type = MessageType.text,
    required this.isUser,
    DateTime? timestamp,
    this.status = MessageStatus.sent,
    this.imageUrl,
    this.fileName,
    this.fileSize,
    this.audioDuration,
    this.thinkingSteps,
    this.metadata,
  })  : id = id ?? const Uuid().v4(),
        timestamp = timestamp ?? DateTime.now();

  MessageModel copyWith({
    String? content,
    MessageType? type,
    bool? isUser,
    MessageStatus? status,
    String? imageUrl,
    String? fileName,
    int? fileSize,
    Duration? audioDuration,
    List<String>? thinkingSteps,
    Map<String, dynamic>? metadata,
  }) {
    return MessageModel(
      id: id,
      content: content ?? this.content,
      type: type ?? this.type,
      isUser: isUser ?? this.isUser,
      timestamp: timestamp,
      status: status ?? this.status,
      imageUrl: imageUrl ?? this.imageUrl,
      fileName: fileName ?? this.fileName,
      fileSize: fileSize ?? this.fileSize,
      audioDuration: audioDuration ?? this.audioDuration,
      thinkingSteps: thinkingSteps ?? this.thinkingSteps,
      metadata: metadata ?? this.metadata,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'content': content,
      'type': type.name,
      'isUser': isUser,
      'timestamp': timestamp.toIso8601String(),
      'status': status.name,
      'imageUrl': imageUrl,
      'fileName': fileName,
      'fileSize': fileSize,
      'audioDuration': audioDuration?.inMilliseconds,
      'thinkingSteps': thinkingSteps,
      'metadata': metadata,
    };
  }

  factory MessageModel.fromJson(Map<String, dynamic> json) {
    return MessageModel(
      id: json['id'],
      content: json['content'],
      type: MessageType.values.byName(json['type']),
      isUser: json['isUser'],
      timestamp: DateTime.parse(json['timestamp']),
      status: MessageStatus.values.byName(json['status']),
      imageUrl: json['imageUrl'],
      fileName: json['fileName'],
      fileSize: json['fileSize'],
      audioDuration: json['audioDuration'] != null
          ? Duration(milliseconds: json['audioDuration'])
          : null,
      thinkingSteps: json['thinkingSteps'] != null
          ? List<String>.from(json['thinkingSteps'])
          : null,
      metadata: json['metadata'],
    );
  }
}
