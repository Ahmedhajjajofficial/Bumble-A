import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/message_model.dart';
import '../models/chat_model.dart';
import '../services/ai_service.dart';

class ChatProvider extends ChangeNotifier {
  final AIService _aiService = AIService();
  
  List<ConversationModel> _conversations = [];
  ConversationModel? _currentConversation;
  bool _isLoading = false;
  bool _isTyping = false;
  String? _error;
  StreamSubscription? _streamSubscription;

  // Getters
  List<ConversationModel> get conversations => _conversations;
  List<ConversationModel> get pinnedConversations => 
      _conversations.where((c) => c.isPinned).toList();
  List<ConversationModel> get unpinnedConversations => 
      _conversations.where((c) => !c.isPinned).toList();
  ConversationModel? get currentConversation => _currentConversation;
  bool get isLoading => _isLoading;
  bool get isTyping => _isTyping;
  String? get error => _error;

  // Initialize
  ChatProvider() {
    _loadConversations();
  }

  Future<void> _loadConversations() async {
    // TODO: Load from local storage
    notifyListeners();
  }

  // Create new conversation
  void createNewConversation({
    String title = 'New Chat',
    ChatModel model = ChatModel.gpt4Turbo,
    String? systemPrompt,
  }) {
    final conversation = ConversationModel(
      title: title,
      model: model,
      systemPrompt: systemPrompt,
    );
    _conversations.insert(0, conversation);
    _currentConversation = conversation;
    notifyListeners();
  }

  // Select conversation
  void selectConversation(String conversationId) {
    _currentConversation = _conversations.firstWhere(
      (c) => c.id == conversationId,
      orElse: () => _conversations.first,
    );
    notifyListeners();
  }

  // Delete conversation
  void deleteConversation(String conversationId) {
    _conversations.removeWhere((c) => c.id == conversationId);
    if (_currentConversation?.id == conversationId) {
      _currentConversation = _conversations.isNotEmpty ? _conversations.first : null;
    }
    notifyListeners();
  }

  // Toggle pin
  void togglePinConversation(String conversationId) {
    final index = _conversations.indexWhere((c) => c.id == conversationId);
    if (index != -1) {
      final conversation = _conversations[index];
      _conversations[index] = conversation.copyWith(
        isPinned: !conversation.isPinned,
      );
      _sortConversations();
      notifyListeners();
    }
  }

  void _sortConversations() {
    _conversations.sort((a, b) {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
  }

  // Send message
  Future<void> sendMessage(String content, {MessageType type = MessageType.text}) async {
    if (content.trim().isEmpty) return;

    if (_currentConversation == null) {
      createNewConversation();
    }

    // Add user message
    final userMessage = MessageModel(
      content: content,
      type: type,
      isUser: true,
      status: MessageStatus.sent,
    );

    _currentConversation!.messages.add(userMessage);
    _isTyping = true;
    _error = null;
    notifyListeners();

    // Generate AI response
    await _generateAIResponse();
  }

  Future<void> _generateAIResponse() async {
    if (_currentConversation == null) return;

    try {
      _isLoading = true;
      notifyListeners();

      // Create thinking message
      final thinkingMessage = MessageModel(
        content: '',
        type: MessageType.thinking,
        isUser: false,
        status: MessageStatus.sending,
      );
      _currentConversation!.messages.add(thinkingMessage);
      notifyListeners();

      // Get conversation history
      final history = _currentConversation!.messages
          .where((m) => m.type == MessageType.text)
          .map((m) => {'role': m.isUser ? 'user' : 'assistant', 'content': m.content})
          .toList();

      // Call AI service
      final response = await _aiService.sendMessage(
        messages: history,
        model: _currentConversation!.model,
        systemPrompt: _currentConversation!.systemPrompt,
      );

      // Replace thinking message with actual response
      _currentConversation!.messages.removeLast();
      
      final aiMessage = MessageModel(
        content: response,
        type: MessageType.text,
        isUser: false,
        status: MessageStatus.sent,
      );
      _currentConversation!.messages.add(aiMessage);

      // Update conversation title if it's the first message
      if (_currentConversation!.messages.length == 2) {
        _updateConversationTitle();
      }

    } catch (e) {
      _error = e.toString();
      // Remove thinking message on error
      if (_currentConversation!.messages.isNotEmpty &&
          _currentConversation!.messages.last.type == MessageType.thinking) {
        _currentConversation!.messages.removeLast();
      }
    } finally {
      _isLoading = false;
      _isTyping = false;
      notifyListeners();
    }
  }

  Future<void> _updateConversationTitle() async {
    if (_currentConversation == null || _currentConversation!.messages.isEmpty) return;
    
    try {
      final firstMessage = _currentConversation!.messages.first.content;
      final title = firstMessage.length > 30 
          ? '${firstMessage.substring(0, 30)}...' 
          : firstMessage;
      
      final index = _conversations.indexWhere((c) => c.id == _currentConversation!.id);
      if (index != -1) {
        _conversations[index] = _currentConversation!.copyWith(title: title);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Error updating title: $e');
    }
  }

  // Regenerate last response
  Future<void> regenerateLastResponse() async {
    if (_currentConversation == null || _currentConversation!.messages.isEmpty) return;
    
    // Remove last AI message if exists
    if (!_currentConversation!.messages.last.isUser) {
      _currentConversation!.messages.removeLast();
    }
    
    await _generateAIResponse();
  }

  // Clear current chat
  void clearCurrentChat() {
    if (_currentConversation != null) {
      _currentConversation!.messages.clear();
      notifyListeners();
    }
  }

  // Stop generation
  void stopGeneration() {
    _streamSubscription?.cancel();
    _isLoading = false;
    _isTyping = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _streamSubscription?.cancel();
    super.dispose();
  }
}
