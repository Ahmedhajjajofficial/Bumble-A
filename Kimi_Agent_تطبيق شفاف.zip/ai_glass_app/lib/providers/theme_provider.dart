import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AppTheme {
  light,
  dark,
  system,
}

class ThemeProvider extends ChangeNotifier {
  static const String _themeKey = 'app_theme';
  
  AppTheme _appTheme = AppTheme.system;
  bool _useGlassEffect = true;
  double _blurAmount = 20.0;
  double _glassOpacity = 0.15;

  // Getters
  AppTheme get appTheme => _appTheme;
  bool get useGlassEffect => _useGlassEffect;
  double get blurAmount => _blurAmount;
  double get glassOpacity => _glassOpacity;

  ThemeMode get themeMode {
    switch (_appTheme) {
      case AppTheme.light:
        return ThemeMode.light;
      case AppTheme.dark:
        return ThemeMode.dark;
      case AppTheme.system:
        return ThemeMode.system;
    }
  }

  bool get isDarkMode => _appTheme == AppTheme.dark;
  bool get isLightMode => _appTheme == AppTheme.light;

  ThemeProvider() {
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final themeIndex = prefs.getInt(_themeKey);
    if (themeIndex != null) {
      _appTheme = AppTheme.values[themeIndex];
      notifyListeners();
    }
  }

  Future<void> setTheme(AppTheme theme) async {
    _appTheme = theme;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_themeKey, theme.index);
    notifyListeners();
  }

  void toggleTheme() {
    if (_appTheme == AppTheme.light) {
      setTheme(AppTheme.dark);
    } else {
      setTheme(AppTheme.light);
    }
  }

  void setGlassEffect(bool value) {
    _useGlassEffect = value;
    notifyListeners();
  }

  void setBlurAmount(double value) {
    _blurAmount = value.clamp(0, 50);
    notifyListeners();
  }

  void setGlassOpacity(double value) {
    _glassOpacity = value.clamp(0.05, 0.5);
    notifyListeners();
  }
}
