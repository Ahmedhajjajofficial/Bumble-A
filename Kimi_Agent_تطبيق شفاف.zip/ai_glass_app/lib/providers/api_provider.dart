import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/chat_model.dart';

class APIConfig {
  final String provider;
  final String apiKey;
  final String? baseUrl;
  final Map<String, dynamic>? additionalHeaders;
  final bool isEnabled;

  APIConfig({
    required this.provider,
    required this.apiKey,
    this.baseUrl,
    this.additionalHeaders,
    this.isEnabled = true,
  });

  APIConfig copyWith({
    String? provider,
    String? apiKey,
    String? baseUrl,
    Map<String, dynamic>? additionalHeaders,
    bool? isEnabled,
  }) {
    return APIConfig(
      provider: provider ?? this.provider,
      apiKey: apiKey ?? this.apiKey,
      baseUrl: baseUrl ?? this.baseUrl,
      additionalHeaders: additionalHeaders ?? this.additionalHeaders,
      isEnabled: isEnabled ?? this.isEnabled,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'provider': provider,
      'apiKey': apiKey,
      'baseUrl': baseUrl,
      'additionalHeaders': additionalHeaders,
      'isEnabled': isEnabled,
    };
  }

  factory APIConfig.fromJson(Map<String, dynamic> json) {
    return APIConfig(
      provider: json['provider'],
      apiKey: json['apiKey'],
      baseUrl: json['baseUrl'],
      additionalHeaders: json['additionalHeaders'],
      isEnabled: json['isEnabled'] ?? true,
    );
  }
}

class APIProvider extends ChangeNotifier {
  static const String _apiKeysKey = 'api_keys';
  static const String _defaultModelKey = 'default_model';

  final Map<String, APIConfig> _apiConfigs = {};
  ChatModel _defaultModel = ChatModel.gpt4Turbo;
  bool _isLoading = false;
  String? _error;

  // Getters
  Map<String, APIConfig> get apiConfigs => _apiConfigs;
  ChatModel get defaultModel => _defaultModel;
  bool get isLoading => _isLoading;
  String? get error => _error;

  List<String> get configuredProviders => _apiConfigs.keys.toList();

  bool get hasAnyAPIKey => _apiConfigs.values.any((config) => 
      config.apiKey.isNotEmpty && config.isEnabled);

  APIProvider() {
    _loadAPIConfigs();
  }

  Future<void> _loadAPIConfigs() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Load default model
      final defaultModelStr = prefs.getString(_defaultModelKey);
      if (defaultModelStr != null) {
        _defaultModel = ChatModel.values.firstWhere(
          (m) => m.name == defaultModelStr,
          orElse: () => ChatModel.gpt4Turbo,
        );
      }

      // Load API configs
      final apiKeysJson = prefs.getString(_apiKeysKey);
      if (apiKeysJson != null) {
        // Parse and load configs
        // This is a simplified version - in production, use secure storage
      }

    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> saveAPIConfig(APIConfig config) async {
    _apiConfigs[config.provider] = config;
    await _persistAPIConfigs();
    notifyListeners();
  }

  Future<void> removeAPIConfig(String provider) async {
    _apiConfigs.remove(provider);
    await _persistAPIConfigs();
    notifyListeners();
  }

  Future<void> _persistAPIConfigs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final configsJson = _apiConfigs.map(
        (key, value) => MapEntry(key, value.toJson()),
      );
      // In production, use secure storage for API keys
      await prefs.setString(_apiKeysKey, configsJson.toString());
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> setDefaultModel(ChatModel model) async {
    _defaultModel = model;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_defaultModelKey, model.name);
    notifyListeners();
  }

  APIConfig? getConfigForProvider(String provider) {
    return _apiConfigs[provider];
  }

  APIConfig? getConfigForModel(ChatModel model) {
    return _apiConfigs[model.provider];
  }

  String? getAPIKeyForProvider(String provider) {
    return _apiConfigs[provider]?.apiKey;
  }

  String? getAPIKeyForModel(ChatModel model) {
    return getAPIKeyForProvider(model.provider);
  }

  bool isProviderConfigured(String provider) {
    final config = _apiConfigs[provider];
    return config != null && config.apiKey.isNotEmpty && config.isEnabled;
  }

  bool isModelConfigured(ChatModel model) {
    return isProviderConfigured(model.provider);
  }

  // Quick setup methods for popular providers
  Future<void> setupOpenAI(String apiKey) async {
    await saveAPIConfig(APIConfig(
      provider: 'OpenAI',
      apiKey: apiKey,
      baseUrl: 'https://api.openai.com/v1',
    ));
  }

  Future<void> setupAnthropic(String apiKey) async {
    await saveAPIConfig(APIConfig(
      provider: 'Anthropic',
      apiKey: apiKey,
      baseUrl: 'https://api.anthropic.com/v1',
      additionalHeaders: {
        'anthropic-version': '2023-06-01',
      },
    ));
  }

  Future<void> setupGoogle(String apiKey) async {
    await saveAPIConfig(APIConfig(
      provider: 'Google',
      apiKey: apiKey,
      baseUrl: 'https://generativelanguage.googleapis.com/v1',
    ));
  }

  Future<void> setupCustomProvider({
    required String name,
    required String apiKey,
    required String baseUrl,
    Map<String, dynamic>? headers,
  }) async {
    await saveAPIConfig(APIConfig(
      provider: name,
      apiKey: apiKey,
      baseUrl: baseUrl,
      additionalHeaders: headers,
    ));
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
