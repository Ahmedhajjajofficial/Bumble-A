# AI Glass 🤖✨

<p align="center">
  <img src="https://img.shields.io/badge/Flutter-3.16+-02569B?style=for-the-badge&logo=flutter&logoColor=white" />
  <img src="https://img.shields.io/badge/Dart-3.0+-0175C2?style=for-the-badge&logo=dart&logoColor=white" />
  <img src="https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge" />
  <img src="https://img.shields.io/badge/Platform-iOS%20%7C%20Android%20%7C%20Web%20%7C%20Desktop-9cf?style=for-the-badge" />
</p>

<p align="center">
  <b>AI Glass</b> is a modern, cross-platform AI chat application featuring a stunning Liquid Glass UI design. Built with Flutter, it offers seamless integration with multiple AI providers including OpenAI, Anthropic, Google, and custom APIs.
</p>

<p align="center">
  <img src="screenshots/app_preview.png" alt="AI Glass Preview" width="800" />
</p>

## ✨ Features

### 🎨 Design
- **Liquid Glass UI** - Stunning frosted glass interface inspired by iOS design principles
- **Adaptive Themes** - Light, dark, and system theme support
- **Smooth Animations** - Fluid transitions and micro-interactions
- **Responsive Design** - Works perfectly on mobile, tablet, and desktop

### 🤖 AI Capabilities
- **Multi-Provider Support** - Connect to OpenAI, Anthropic, Google, and custom APIs
- **Model Selection** - Choose from GPT-4, Claude 3, Gemini, and more
- **Streaming Responses** - Real-time AI message streaming
- **Conversation Management** - Save, organize, and search chats

### 🔧 Customization
- **Glass Effect Controls** - Adjust blur and opacity to your preference
- **API Configuration** - Easy setup for multiple AI providers
- **Personal Settings** - Customize your experience

### 📱 Cross-Platform
- **iOS & Android** - Native mobile experience
- **Web** - Run in any modern browser
- **Desktop** - Windows, macOS, and Linux support

## 🚀 Getting Started

### Prerequisites

- Flutter SDK 3.16 or higher
- Dart SDK 3.0 or higher
- An API key from your preferred AI provider

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/ai_glass.git
   cd ai_glass
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Configure API Keys**
   
   Open the app and navigate to **Settings > AI Models & API** to configure your API keys:
   
   - **OpenAI**: Get your key from [OpenAI Dashboard](https://platform.openai.com/api-keys)
   - **Anthropic**: Get your key from [Anthropic Console](https://console.anthropic.com/)
   - **Google**: Get your key from [Google AI Studio](https://makersuite.google.com/app/apikey)

4. **Run the app**
   ```bash
   flutter run
   ```

## 🏗️ Project Structure

```
ai_glass/
├── lib/
│   ├── main.dart                 # App entry point
│   ├── models/                   # Data models
│   │   ├── message_model.dart    # Chat message model
│   │   └── chat_model.dart       # Conversation model
│   ├── providers/                # State management
│   │   ├── chat_provider.dart    # Chat state
│   │   ├── theme_provider.dart   # Theme state
│   │   └── api_provider.dart     # API configuration
│   ├── screens/                  # UI screens
│   │   ├── splash_screen.dart    # Splash screen
│   │   ├── home_screen.dart      # Main screen
│   │   ├── chat_screen.dart      # Chat interface
│   │   └── settings_screen.dart  # Settings page
│   ├── services/                 # Business logic
│   │   └── ai_service.dart       # AI API integration
│   ├── theme/                    # App theming
│   │   ├── app_theme.dart        # Theme definitions
│   │   └── app_colors.dart       # Color palette
│   ├── utils/                    # Utilities
│   │   ├── extensions.dart       # Dart extensions
│   │   └── helpers.dart          # Helper functions
│   └── widgets/                  # Reusable widgets
│       ├── glass_widgets.dart    # Glass UI components
│       ├── message_bubble.dart   # Message bubble
│       └── typing_indicator.dart # Typing animation
├── assets/                       # Static assets
├── pubspec.yaml                  # Dependencies
└── README.md                     # This file
```

## 🔌 API Integration

### Supported Providers

| Provider | Models | Setup |
|----------|--------|-------|
| OpenAI | GPT-4, GPT-4 Turbo, GPT-3.5 Turbo | `sk-...` |
| Anthropic | Claude 3, Claude 3.5 | `sk-ant-...` |
| Google | Gemini Pro, Gemini Ultra | `AIza...` |
| Custom | Any OpenAI-compatible API | Custom URL |

### Adding a Custom Provider

1. Go to **Settings > AI Models & API > Custom Provider**
2. Enter:
   - Provider Name
   - API Key
   - Base URL (e.g., `https://api.example.com/v1`)
3. Save and start chatting!

## 🎨 Customization

### Glass Effect Settings

Adjust the glass morphism effect in **Settings > Glass Effect**:

- **Blur Amount**: 0-50 (default: 20)
- **Opacity**: 0.05-0.5 (default: 0.15)

### Theme Configuration

The app supports three theme modes:
- 🌞 **Light** - Bright, clean interface
- 🌙 **Dark** - Easy on the eyes
- 🖥️ **System** - Follows device settings

## 📱 Platform Support

| Platform | Status | Notes |
|----------|--------|-------|
| iOS | ✅ Supported | iOS 12+ |
| Android | ✅ Supported | API 21+ |
| Web | ✅ Supported | Modern browsers |
| Windows | ✅ Supported | Windows 10+ |
| macOS | ✅ Supported | macOS 10.14+ |
| Linux | ✅ Supported | GTK 3.0+ |

## 🛠️ Development

### Running Tests

```bash
flutter test
```

### Building for Production

```bash
# iOS
flutter build ios --release

# Android
flutter build apk --release
flutter build appbundle --release

# Web
flutter build web --release

# Desktop
flutter build windows --release
flutter build macos --release
flutter build linux --release
```

### Code Generation

```bash
# Generate code (if using build_runner)
flutter pub run build_runner build --delete-conflicting-outputs
```

## 📦 Dependencies

Key packages used in this project:

| Package | Purpose |
|---------|---------|
| `provider` | State management |
| `glassmorphism` | Glass effect |
| `flutter_animate` | Animations |
| `dio` | HTTP client |
| `shared_preferences` | Local storage |
| `google_fonts` | Typography |

See `pubspec.yaml` for the complete list.

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

Please read our [Contributing Guide](CONTRIBUTING.md) for details.

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Design inspired by Apple's iOS Liquid Glass UI
- Built with [Flutter](https://flutter.dev)
- Icons by [Font Awesome](https://fontawesome.com)

## 📞 Support

If you encounter any issues or have questions:

- 🐛 [Report a bug](../../issues)
- 💡 [Request a feature](../../issues)
- 📧 Contact: your.email@example.com

## 🔮 Roadmap

- [ ] Voice input support
- [ ] Image generation integration
- [ ] Chat export (PDF, Markdown)
- [ ] Multi-language support
- [ ] Plugin system
- [ ] Cloud sync

---

<p align="center">
  Made with ❤️ using Flutter
</p>
