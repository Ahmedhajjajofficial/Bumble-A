import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ai_glass_app/main.dart';

void main() {
  testWidgets('App launches and shows splash screen', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const AIGlassApp());

    // Verify that the splash screen is shown
    expect(find.text('AI Glass'), findsOneWidget);
    expect(find.text('Experience the Future of AI'), findsOneWidget);
  });

  testWidgets('Theme provider works correctly', (WidgetTester tester) async {
    await tester.pumpWidget(const AIGlassApp());
    
    // Verify app builds without errors
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}
